# VCK Engineers Wing — Professional Static Website

Files:
- index.html
- style.css
- script.js

Existing photo filenames expected in the repository root:
- IMG_1495.jpeg
- IMG_2160.jpeg
- IMG_2178.jpeg
- IMG_2211.jpeg
- IMG_2222.jpeg

Upload the three website files to the same GitHub repository as the photos.
For a static Vercel deployment:
- Application Preset: Other
- Root Directory: ./
- Build Command: leave empty
- Output Directory: leave empty
- Install Command: leave empty

Replace the placeholder contact details with confirmed official information before publishing.


## VCK branding update
The package now includes `vck-engineers-logo.jpeg` and displays the supplied VCK Engineers Wing logo and Head Office address:
Sarvamangala Colony, Ashoka Colony, Ashok Nagar, Chennai – 600083, Tamil Nadu, India.

Upload `vck-engineers-logo.jpeg` to the same GitHub repository level as `index.html`.
