const menuBtn=document.querySelector(".menu-btn");
const nav=document.querySelector("#nav");
menuBtn?.addEventListener("click",()=>{const open=nav.classList.toggle("open");menuBtn.setAttribute("aria-expanded",open)});
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const modal=document.querySelector("#modal");
const modalImg=document.querySelector("#modal-image");
document.querySelectorAll(".photo").forEach(btn=>{
  btn.addEventListener("click",()=>{
    modalImg.src=btn.dataset.full;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden","false");
  });
});
function closeModal(){modal.classList.remove("open");modal.setAttribute("aria-hidden","true");modalImg.src=""}
document.querySelector(".modal-close")?.addEventListener("click",closeModal);
modal?.addEventListener("click",e=>{if(e.target===modal)closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
document.querySelector("#year").textContent=new Date().getFullYear();
